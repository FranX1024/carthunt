// TODO: Fix noclip

class Point2d {
public:
  double x, y;
  Point2d(int x, int y) {
    this->x = x;
    this->y = y;
  }
};

class GameMap {
public:

  // permanent
  scene::IMesh* mesh;
  video::ITexture* texture;
  scene::ISceneManager* smgr;

  scene::IMesh* shelf_mesh;
  video::ITexture* shelf_texture;
  
  int tiles[32][32];
  
  int rows = 32;
  int cols = 32;

  // change on setup
  scene::ISceneNode* node;
  
  GameMap(scene::ISceneManager* smgr, video::IVideoDriver* driver);
  void setup();
  bool collides(std::vector<Point2d> polygon);
};
