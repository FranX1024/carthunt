Game::Game(Application* app) : Activity(app) {
  this->app->smgr->setAmbientLight(video::SColorf(.6f,.6f,.6f,1.0f));

  // init map
  this->map = new GameMap(this->app->smgr, this->app->driver);
  
  // init player
  scene::IMesh* player_mesh = this->app->smgr->getMesh("./res/model/barba/barba.obj");
  if(!player_mesh) {
    printf("Error! Could not load barba.obj!");
    this->successfully_initialized = false;
    return;
  }
  video::ITexture* player_texture = this->app->driver->getTexture("./res/model/barba/barba_texture.png");
  this->player = new Player(this->app->smgr, player_mesh, player_texture, this->map);

  // init ball
  scene::IMesh* ball_mesh = this->app->smgr->getMesh("./res/model/ball/ball.obj");
  if(!player_mesh) {
    printf("Error! Could not load barba.obj!");
    this->successfully_initialized = false;
    return;
  }
  video::ITexture* ball_texture = this->app->driver->getTexture("./res/model/ball/texture.png");
  this->ball = new Ball(this->app->smgr, ball_mesh, ball_texture, this->map);
}

void Game::setup() {
  // setup game objects
  this->player->setup();
  this->map->setup();
  this->ball->setup();
  
  this->camera = this->app->smgr->addCameraSceneNode();
  this->updateCamera();

  scene::ILightSceneNode * light = this->app->smgr->addLightSceneNode(0, core::vector3df(-60,100,400),
							   video::SColorf(1.0f,1.0f,1.0f,1.0f), 200.0f);
  
}

void Game::update() {
  // keep track of time
  int newT = this->app->device->getTimer()->getTime();
  double dt = this->lastT == 0 ? .001 : ((double)(newT - this->lastT) * .001);
  this->lastT = newT;

  // precompute
  double player_rotation_sin = sin(this->player->rotation);
  double player_rotation_cos = cos(this->player->rotation);
  
  // player movement
  if(this->app->keydown[38] or this->app->keydown[87]) { // forward
    this->player->velocityX += this->player->acceleration * dt * player_rotation_sin;
    this->player->velocityZ += this->player->acceleration * dt * player_rotation_cos;
    double total_velocity = squareNum(this->player->velocityX) + squareNum(this->player->velocityZ);
    if(total_velocity > squareNum(this->player->maxspeed)) {
      this->player->velocityX = this->player->maxspeed * player_rotation_sin;
      this->player->velocityZ = this->player->maxspeed * player_rotation_cos;
    }
  }
  if(this->app->keydown[40] or this->app->keydown[83]) { // backward
    this->player->velocityX -= this->player->acceleration * dt * player_rotation_sin * .5;
    this->player->velocityZ -= this->player->acceleration * dt * player_rotation_cos * .5;
    double total_velocity = squareNum(this->player->velocityX) + squareNum(this->player->velocityZ);
    if(total_velocity > squareNum(this->player->maxspeed)) {
      this->player->velocityX = -this->player->maxspeed * player_rotation_sin;
      this->player->velocityZ = -this->player->maxspeed * player_rotation_cos;
    }
  }
  if(this->app->keydown[37] or this->app->keydown[65]) { // left
    this->player->rotate(-this->player->rspeed * dt);
  }
  if(this->app->keydown[39] or this->app->keydown[68]) { // right
    this->player->rotate(this->player->rspeed * dt);
  }
  // throw ball
  if(this->app->keydown[32]) {
    this->ball->position = this->player->position;
    this->ball->velocityZ = this->player->velocityZ + player_rotation_cos * 20;
    this->ball->velocityX = this->player->velocityX + player_rotation_sin * 20;
    this->ball->velocityY = 20;
  }
  
  this->ball->update(dt);
  this->player->update(dt);
  this->updateCamera();
}

void Game::updateCamera() {
  core::vector3df camera_pos = core::vector3df(this->player->position.X - 10 * sin(this->player->camera_rotation),
					       this->player->position.Y + 10,
					       this->player->position.Z - 10 * cos(this->player->camera_rotation));
  
  core::vector3df camera_targ = core::vector3df(camera_pos.X + 12 * sin(this->player->camera_rotation),
						this->player->position.Y,
						camera_pos.Z + 12 * cos(this->player->camera_rotation));
    
  this->camera->setPosition(camera_pos);
  this->camera->setTarget(camera_targ);
}

void Game::onevent(const SEvent &event) {
}

void Game::drop() {
  delete this->player;
}
