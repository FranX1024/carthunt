Activity::Activity(Application* parent) {
  this->app = parent;
}

void Activity::setup() {}
void Activity::update() {}
void Activity::onevent(const SEvent &event) {}
void Activity::drop() {}
