class Game : public Activity {
public:
  Game(Application* app);
  
  virtual void setup();
  virtual void update();
  virtual void onevent(const SEvent &event);
  virtual void drop();

  void updateCamera();

  bool successfully_initialized = true;

  scene::ICameraSceneNode* camera;

  Ball* ball;
  Player* player;
  GameMap* map;

  int lastT = 0;
};

