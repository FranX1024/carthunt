ITexture* title_image;
void init_title();
void update_title();
