IrrlichtDevice* irrDevice;
IVideoDriver* irrDriver;
ISceneManager* irrSmgr;
IGUIEnvironment* irrGuienv;

ICameraSceneNode* irrCamera;
