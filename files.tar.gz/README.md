# IMPORTANT:

## Make sure to first download irrlicht-1.8.5 and put it in the rootfolder