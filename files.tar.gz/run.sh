cd bin
./game.o
cd ..
